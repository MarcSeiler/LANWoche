﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace SimpleReceive
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        static int port = 8000;
        static TcpListener listener = new TcpListener(IPAddress.Any, port);


        public MainWindow()
        {
            InitializeComponent();
        }

        void clientWorker(Object o)
        {
            TcpClient client = (TcpClient) o;
            string dataReceived;

            do
            {
                NetworkStream nwStream = client.GetStream();
                byte[] buffer = new byte[client.ReceiveBufferSize];

                Debug.WriteLine("--> Wait for data");
                int bytesRead = nwStream.Read(buffer, 0, client.ReceiveBufferSize);
                Debug.WriteLine("--> Data received");

                dataReceived = Encoding.UTF8.GetString(buffer, 0, bytesRead);

                Dispatcher.Invoke(() => { TBxReceivedText.Text = dataReceived; });
                

            } while (dataReceived != "q");

            Debug.WriteLine("--> Disconnect");
            client.Close();

        }

        void ListenWorker()
        {
            while (true)
            {
                Debug.WriteLine("--> Wait for connection");
                TcpClient client = listener.AcceptTcpClient();
                Debug.WriteLine("--> Connected");

             
                // ParameterizedThreadStart ...
                Thread clientThread = new Thread(clientWorker);
                clientThread.Start(client);
            }

        }
        private void BtnStartListen_Click(object sender, RoutedEventArgs e)
        {
            listener.Start();

            Thread ListenThread = new Thread(ListenWorker);
            ListenThread.Start();

        }



        private void BtnStopListen_Click(object sender, RoutedEventArgs e)
        {
            listener.Stop();
        }

        private void BtnQuit_Click(object sender, RoutedEventArgs e)
        {
            System.Windows.Application.Current.Shutdown();
        }
    }
}
